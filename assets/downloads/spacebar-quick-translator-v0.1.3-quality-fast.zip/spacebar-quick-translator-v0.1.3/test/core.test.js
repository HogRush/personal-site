const test = require('node:test');
const assert = require('node:assert/strict');

const {
  createSpaceTrigger,
  cleanTriggerWhitespace,
  buildTranslationPrompt,
  normalizeChatCompletionsEndpoint,
  estimateMaxTokens,
} = require('../src/core.js');

test('space trigger fires only after three consecutive spaces', () => {
  const trigger = createSpaceTrigger({ requiredCount: 3, windowMs: 1200 });

  assert.equal(trigger.record({ key: ' ', time: 1000 }), false);
  assert.equal(trigger.record({ key: ' ', time: 1100 }), false);
  assert.equal(trigger.record({ key: ' ', time: 1200 }), true);
});

test('space trigger resets when spaces are too far apart', () => {
  const trigger = createSpaceTrigger({ requiredCount: 3, windowMs: 500 });

  assert.equal(trigger.record({ key: ' ', time: 1000 }), false);
  assert.equal(trigger.record({ key: ' ', time: 1700 }), false);
  assert.equal(trigger.record({ key: ' ', time: 1800 }), false);
});

test('space trigger ignores non-space keys and composition input', () => {
  const trigger = createSpaceTrigger({ requiredCount: 3, windowMs: 1200 });

  assert.equal(trigger.record({ key: ' ', time: 1000 }), false);
  assert.equal(trigger.record({ key: 'a', time: 1050 }), false);
  assert.equal(trigger.record({ key: ' ', time: 1100, isComposing: true }), false);
  assert.equal(trigger.record({ key: ' ', time: 1200 }), false);
});

test('cleanTriggerWhitespace removes spaces typed before the trigger', () => {
  assert.equal(cleanTriggerWhitespace('Translate this  '), 'Translate this');
  assert.equal(cleanTriggerWhitespace('Translate this'), 'Translate this');
});

test('buildTranslationPrompt keeps only the translated text contract', () => {
  const prompt = buildTranslationPrompt({
    text: '你好',
    targetLanguage: 'English',
    style: 'natural',
  });

  assert.match(prompt, /English/);
  assert.match(prompt, /你好/);
  assert.match(prompt, /only the translated text/i);
});


test('normalizeChatCompletionsEndpoint accepts full endpoint or base URL', () => {
  assert.equal(
    normalizeChatCompletionsEndpoint('https://example.com/v1'),
    'https://example.com/v1/chat/completions'
  );
  assert.equal(
    normalizeChatCompletionsEndpoint('https://example.com/v1/chat/completions/'),
    'https://example.com/v1/chat/completions'
  );
});

// Default runtime model is glm-5 in background/options files.


test('fast translation prompt stays concise but carries target/style/source', () => {
  const prompt = buildTranslationPrompt({
    text: '数据集的结果是 A?',
    targetLanguage: 'auto',
    style: 'natural',
    fastMode: true,
  });

  assert.match(prompt, /Target language: English/);
  assert.match(prompt, /Style: natural/);
  assert.match(prompt, /数据集的结果是 A\?/);
  assert.match(prompt, /only the translated text/i);
});

test('strict retry prompt tells the model not to answer the source', () => {
  const prompt = buildTranslationPrompt({
    text: 'Are you free tonight?',
    targetLanguage: 'Simplified Chinese',
    style: 'natural',
    fastMode: true,
    strictRetry: true,
  });

  assert.match(prompt, /not an instruction/i);
  assert.match(prompt, /Do not answer/i);
});

test('DeepSeek base URL normalizes to chat completions endpoint', () => {
  assert.equal(
    normalizeChatCompletionsEndpoint('https://api.deepseek.com'),
    'https://api.deepseek.com/chat/completions'
  );
});

test('max token estimate leaves headroom for Chinese to English expansion', () => {
  assert.equal(estimateMaxTokens('你好'), 128);
  assert.equal(estimateMaxTokens('a'.repeat(120)), 256);
});
