# Spacebar Quick Translator v0.1.3

A personal Chrome/Edge extension that translates focused input text after pressing Space three times.

## What changed in v0.1.3

- DeepSeek requests explicitly send `"thinking": {"type": "disabled"}` to avoid unnecessary reasoning latency.
- The normal fast path still uses a short prompt, but now has a stable precision-focused system instruction.
- Questions and instructions inside the source text are treated as text to translate, not commands to answer.
- Names, numbers, dates, units, URLs, code, emoji, punctuation, and line breaks are explicitly protected.
- Proper nouns use established target-language forms only when the model is confident; otherwise it is told to transliterate conservatively.
- A conservative quality guard checks for empty output, truncation, obvious target-language mismatch, accidental explanation labels, and runaway/hallucinated output.
- Only when the first result is clearly suspicious does the extension retry once with a stricter prompt. Valid translations keep the one-request low-latency path.
- `reasoning_content` is never used as the final translation.
- `max_tokens` has more headroom to avoid truncating Chinese -> English translations. It is a ceiling; billing still depends on actual generated tokens.
- Cache keys now include translation style and prompt version.
- A successful API test is automatically saved, so the real triple-space translation uses the same tested settings.
- DeepSeek's bare base URL `https://api.deepseek.com` is normalized to `/chat/completions`.
- API latency logs now separate response-header wait, body read, and total time.

## Recommended settings

- API endpoint: `https://api.deepseek.com/chat/completions`
- Model: `deepseek-v4-flash`
- Target language: `auto`
- Style: `natural`
- Fast mode: ON

## Install

1. Open `chrome://extensions` or `edge://extensions`.
2. Enable Developer mode.
3. Click "Load unpacked".
4. Select the `spacebar-quick-translator-v0.1.3` folder.
5. Enter your API key, endpoint, and model.
6. Click "Test API". If it passes, the tested settings are saved automatically.
7. Refresh the webpage where you want to use the extension.

## Usage

1. Focus an input, textarea, or contenteditable box.
2. Type or paste text.
3. Press Space three times quickly.
4. The extension translates selected text, or the full input if nothing is selected.

## Development

Run:

```sh
npm test
```
