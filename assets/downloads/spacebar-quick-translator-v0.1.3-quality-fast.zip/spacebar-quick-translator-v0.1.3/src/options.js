const DEFAULT_SETTINGS = {
  apiKey: '',
  baseUrl: 'https://api.deepseek.com/chat/completions',
  model: 'deepseek-v4-flash',
  targetLanguage: 'auto',
  style: 'natural',
  fastMode: true,
};

const form = document.querySelector('#options-form');
const status = document.querySelector('#status');
const testButton = document.querySelector('#test-api');

loadOptions();

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const settings = getFormSettings();
  await chrome.storage.sync.set(settings);

  setStatus('Saved', 'success');
  window.setTimeout(() => {
    setStatus('', '');
  }, 1600);
});

testButton.addEventListener('click', async () => {
  const settings = getFormSettings();

  setStatus('Testing API connection...', 'loading');
  testButton.disabled = true;

  try {
    const response = await withTimeout(
      chrome.runtime.sendMessage({
        type: 'SPACEBAR_TEST_API',
        settings,
      }),
      18000,
      'API test timed out. Please check the model, endpoint, network, or service worker.'
    );

    if (!response || !response.ok) {
      throw new Error(response && response.error ? response.error : 'API test failed.');
    }

    // Important: the settings that passed the test become the settings used
    // by the real triple-space translation immediately.
    await chrome.storage.sync.set(settings);

    const thinkingStatus = response.thinking ? ' ' + response.thinking + '.' : '';
    setStatus(
      response.message +
        ' Endpoint: ' +
        response.endpoint +
        '. ' +
        response.auth +
        '.' +
        thinkingStatus +
        ' Settings saved.',
      'success'
    );
  } catch (error) {
    setStatus(error.message || String(error), 'error');
  } finally {
    testButton.disabled = false;
  }
});

async function loadOptions() {
  const settings = await chrome.storage.sync.get(DEFAULT_SETTINGS);

  for (const [key, value] of Object.entries(settings)) {
    const input = form.elements[key];
    if (!input) continue;

    if (input.type === 'checkbox') {
      input.checked = value !== false && value !== 'false';
    } else {
      input.value = value;
    }
  }
}

function getFormSettings() {
  const settings = Object.fromEntries(new FormData(form).entries());

  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    if (key === 'fastMode') {
      settings[key] = form.elements[key].checked;
      continue;
    }

    settings[key] = String(settings[key] || '').trim();
  }

  return settings;
}

function withTimeout(promise, timeoutMs, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      window.setTimeout(() => reject(new Error(message)), timeoutMs);
    }),
  ]);
}

function setStatus(message, kind) {
  status.textContent = message;
  status.className = kind || '';
}
