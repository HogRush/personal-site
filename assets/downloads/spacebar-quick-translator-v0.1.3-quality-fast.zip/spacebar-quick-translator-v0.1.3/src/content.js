(function initContentScript() {
  const Core = window.SpacebarTranslatorCore;

  if (!Core) {
    console.error('Spacebar Quick Translator: core script was not loaded.');
    return;
  }

  console.log('Spacebar Quick Translator: content script loaded on', location.href);

  function isSpaceKey(event) {
    return event && (event.key === ' ' || event.key === 'Spacebar' || event.code === 'Space');
  }

  const trigger = Core.createSpaceTrigger({ requiredCount: 3, windowMs: 1200 });
  const selectedTrigger = Core.createSpaceTrigger({ requiredCount: 3, windowMs: 1200 });

  let pendingSelectedRequest = null;
  let statusNode = null;
  let activeRequestId = 0;
  let loadingTimer = null;

  document.addEventListener('keydown', (event) => {
    if (event.repeat) return;

    const element = findEditableTarget(event);
    if (!element) return;

    if (!isSpaceKey(event)) {
      trigger.reset();
      selectedTrigger.reset();
      pendingSelectedRequest = null;
      return;
    }

    const currentSelection = getTextSelection(element);
    const hasCurrentSelection = isSelectedText(currentSelection);

    // When text is selected, the first Space would normally replace the selected text.
    // We prevent the Space key and keep the selection until three Spaces are pressed.
    if (hasCurrentSelection || pendingSelectedRequest) {
      event.preventDefault();
      event.stopPropagation();

      if (hasCurrentSelection) {
        pendingSelectedRequest = {
          element,
          selection: currentSelection,
          createdAt: Date.now(),
        };
      }

      const shouldTranslateSelected = selectedTrigger.record({
        code: event.code,
        isComposing: event.isComposing,
        key: event.key,
        time: Date.now(),
      });

      if (shouldTranslateSelected && pendingSelectedRequest) {
        const request = pendingSelectedRequest;
        pendingSelectedRequest = null;
        selectedTrigger.reset();

        console.log('Spacebar Quick Translator: triple-space trigger detected for selected text.');
        translateElement(request.element, request.selection);
      }

      return;
    }

    const shouldTranslate = trigger.record({
      code: event.code,
      isComposing: event.isComposing,
      key: event.key,
      time: Date.now(),
    });

    if (!shouldTranslate) return;

    event.preventDefault();
    event.stopPropagation();

    console.log('Spacebar Quick Translator: triple-space trigger detected.');
    translateElement(element, null);
  }, true);

  async function translateElement(element, savedSelection) {
    const requestId = ++activeRequestId;
    const selection = savedSelection || getTextSelection(element);
    const sourceText = Core.cleanTriggerWhitespace(selection.text);

    if (!sourceText.trim()) {
      showStatus(element, 'No text to translate', 'error');
      return;
    }

    startLoadingStatus(element);

    try {
      console.log('Spacebar Quick Translator: sending translation request. Text length:', sourceText.length);

      const response = await sendExtensionMessageWithTimeout({
        type: 'SPACEBAR_TRANSLATE',
        text: sourceText,
      }, 65000);

      if (requestId !== activeRequestId) return;

      if (!response || !response.ok) {
        throw new Error(response && response.error ? response.error : 'Translation failed. Empty response from background script.');
      }

      replaceText(element, selection, response.translatedText);
      stopLoadingStatus();
      showStatus(element, 'Translated', 'success');
      console.log('Spacebar Quick Translator: translation completed.');
    } catch (error) {
      stopLoadingStatus();
      const message = error && error.message ? error.message : String(error);
      console.error('Spacebar Quick Translator:', message);
      showStatus(element, message, 'error');
    }
  }

  function findEditableTarget(event) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];

    for (const node of path) {
      if (!node || node === window || node === document || node === document.documentElement) {
        continue;
      }

      if (Core.isEditableElement(node)) {
        return node;
      }
    }

    return Core.isEditableElement(event.target) ? event.target : null;
  }

  function isSelectedText(selection) {
    return selection && (
      selection.kind === 'range' ||
      selection.kind === 'contenteditable-range'
    ) && String(selection.text || '').trim().length > 0;
  }

  function getTextSelection(element) {
    const tagName = element.tagName.toLowerCase();

    if (tagName === 'input' || tagName === 'textarea') {
      const start = element.selectionStart;
      const end = element.selectionEnd;
      const hasSelection = typeof start === 'number' && typeof end === 'number' && end > start;

      if (hasSelection) {
        return {
          kind: 'range',
          start,
          end,
          text: element.value.slice(start, end),
        };
      }

      return {
        kind: 'whole',
        start: 0,
        end: element.value.length,
        text: element.value,
      };
    }

    const pageSelection = window.getSelection();
    if (pageSelection && pageSelection.rangeCount > 0 && !pageSelection.isCollapsed) {
      const range = pageSelection.getRangeAt(0);
      if (element.contains(range.commonAncestorContainer)) {
        return {
          kind: 'contenteditable-range',
          range: range.cloneRange(),
          text: pageSelection.toString(),
        };
      }
    }

    return {
      kind: 'contenteditable-whole',
      text: element.innerText || element.textContent || '',
    };
  }

  function replaceText(element, selection, replacement) {
    const text = String(replacement || '');

    if (selection.kind === 'range' || selection.kind === 'whole') {
      replaceInputOrTextareaText(element, selection, text);
      return;
    }

    replaceContentEditableText(element, selection, text);
  }

  function replaceInputOrTextareaText(element, selection, text) {
    element.focus();

    const start = selection.start;
    const end = selection.end;

    if (typeof element.setSelectionRange === 'function') {
      element.setSelectionRange(start, end);
    }

    // Prefer native text insertion. It has a better chance of entering the browser undo stack.
    let insertedByNativeUndoStack = false;

    try {
      if (typeof document.execCommand === 'function') {
        insertedByNativeUndoStack = document.execCommand('insertText', false, text);
      }
    } catch (error) {
      insertedByNativeUndoStack = false;
    }

    if (!insertedByNativeUndoStack) {
      element.setRangeText(text, start, end, 'end');

      element.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertReplacementText',
        data: text,
      }));

      element.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function replaceContentEditableText(element, selection, text) {
    element.focus();

    if (selection.kind === 'contenteditable-range') {
      restoreRange(selection.range);
      insertTextIntoContentEditable(text);
    } else {
      selectElementContents(element);
      insertTextIntoContentEditable(text);
    }

    element.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertReplacementText',
      data: text,
    }));
  }

  function restoreRange(range) {
    const pageSelection = window.getSelection();
    if (!pageSelection) return;

    pageSelection.removeAllRanges();
    pageSelection.addRange(range);
  }

  function selectElementContents(element) {
    const range = document.createRange();
    range.selectNodeContents(element);

    const pageSelection = window.getSelection();
    if (!pageSelection) return;

    pageSelection.removeAllRanges();
    pageSelection.addRange(range);
  }

  function insertTextIntoContentEditable(text) {
    let inserted = false;

    try {
      if (typeof document.execCommand === 'function') {
        inserted = document.execCommand('insertText', false, text);
      }
    } catch (error) {
      inserted = false;
    }

    if (!inserted) {
      const pageSelection = window.getSelection();
      if (!pageSelection || pageSelection.rangeCount === 0) return;

      const range = pageSelection.getRangeAt(0);
      range.deleteContents();

      const node = document.createTextNode(text);
      range.insertNode(node);

      range.setStartAfter(node);
      range.setEndAfter(node);

      pageSelection.removeAllRanges();
      pageSelection.addRange(range);
    }
  }

  function getRuntime() {
    if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
      return chrome.runtime;
    }

    if (typeof browser !== 'undefined' && browser.runtime && typeof browser.runtime.sendMessage === 'function') {
      return browser.runtime;
    }

    return null;
  }

  function sendExtensionMessageWithTimeout(message, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new Error('Translation request timed out after ' + Math.round(timeoutMs / 1000) + ' seconds. Open the options page and click Test API, or check the service worker console.'));
      }, timeoutMs);

      sendExtensionMessage(message)
        .then((response) => {
          clearTimeout(timeoutId);
          resolve(response);
        })
        .catch((error) => {
          clearTimeout(timeoutId);
          reject(error);
        });
    });
  }

  function sendExtensionMessage(message) {
    const runtime = getRuntime();

    if (!runtime) {
      return Promise.reject(new Error('Extension runtime is unavailable. Reload the extension, then refresh this webpage and try again.'));
    }

    return new Promise((resolve, reject) => {
      let settled = false;

      const done = (callback) => {
        if (settled) return;
        settled = true;
        callback();
      };

      try {
        runtime.sendMessage(message, (response) => {
          const lastError = getLastRuntimeError();

          if (lastError) {
            done(() => reject(new Error(lastError.message || String(lastError))));
            return;
          }

          done(() => resolve(response));
        });
      } catch (error) {
        done(() => reject(error));
      }
    });
  }

  function getLastRuntimeError() {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError) {
      return chrome.runtime.lastError;
    }

    if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.lastError) {
      return browser.runtime.lastError;
    }

    return null;
  }

  function startLoadingStatus(element) {
    const startedAt = Date.now();
    showStatus(element, 'Translating...', 'loading');

    clearInterval(loadingTimer);
    loadingTimer = setInterval(() => {
      const seconds = Math.floor((Date.now() - startedAt) / 1000);
      showStatus(element, 'Translating... ' + seconds + 's', 'loading');
    }, 1000);
  }

  function stopLoadingStatus() {
    clearInterval(loadingTimer);
    loadingTimer = null;
  }

  function showStatus(element, message, kind) {
    if (statusNode) statusNode.remove();

    const rect = element.getBoundingClientRect();

    statusNode = document.createElement('div');
    statusNode.textContent = message;
    statusNode.style.position = 'fixed';
    statusNode.style.left = Math.max(8, rect.left) + 'px';
    statusNode.style.top = Math.max(8, rect.top - 34) + 'px';
    statusNode.style.zIndex = '2147483647';
    statusNode.style.maxWidth = '720px';
    statusNode.style.padding = '6px 9px';
    statusNode.style.borderRadius = '6px';
    statusNode.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.18)';
    statusNode.style.font = '12px/1.35 -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif';
    statusNode.style.color = '#ffffff';
    statusNode.style.background = kind === 'error' ? '#b3261e' : kind === 'success' ? '#137333' : '#1f1f1f';
    statusNode.style.pointerEvents = 'none';
    statusNode.style.whiteSpace = 'pre-wrap';

    document.documentElement.appendChild(statusNode);

    if (kind !== 'loading') {
      const hideDelay = kind === 'success' ? 900 : 5600;

      window.setTimeout(() => {
        if (statusNode) {
          statusNode.remove();
          statusNode = null;
        }
      }, hideDelay);
    }
  }
})();
